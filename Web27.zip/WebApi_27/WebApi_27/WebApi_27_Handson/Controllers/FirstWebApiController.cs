﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi_27_Handson.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FirstWebApiController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("GET EXECUTED");
        }
        [HttpPost]
        public IActionResult Post()
        {
            return Ok("POST EXECUTED");
        }
        [HttpPut]
        public IActionResult Put()
        {
            return Ok("PUT EXECUTED");
        }
        [HttpDelete]
        public IActionResult Delete()
        {
            return Ok("DELETE EXECUTED");
        }
    }
}
