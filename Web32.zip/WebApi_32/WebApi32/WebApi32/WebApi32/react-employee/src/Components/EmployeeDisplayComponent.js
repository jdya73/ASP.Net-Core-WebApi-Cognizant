import React from 'react';
import {Row,Col,Container,Table} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';

function EmployeeInsertComponent(props)
{
    return(
        <Table>
            <thead>
                <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Location</th>
                <th>Salary</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{props.id}</td>
                    <td>{props.name}</td>
                    <td>{props.location}</td>
                    <td>{props.salary}</td>
                </tr>
            </tbody>
        </Table>
    )
}
export default EmployeeInsertComponent;