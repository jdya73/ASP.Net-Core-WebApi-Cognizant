import axios from 'axios';
import React,{Component} from 'react';
import {Container,Row,Col} from 'react-bootstrap';
class EmployeeInsertComponent extends React.Component {

    submitHandler(event) {
        event.preventDefault();
        const data={
                        Id:document.getElementById('empid').value,
                        Name:document.getElementById('empname').value,
                        Location:document.getElementById('emploc').value,
                        Salary:document.getElementById('empsal').value
                   };


        const apiurl="http://localhost:31300/api/Employee";
        axios.post(apiurl,data).then((response)=>{
            console.log(response.data);
        })
    }


    render()
    {
        return(
             <Container>
                 <Row><h2>Employee Form</h2></Row>
                     <Row>
                       <Col>
                            <form onSubmit={this.submitHandler}>
                                <table>
                                    <tbody>
                                    <tr>
                                        <td><label>Enter Employee Id:</label></td>
                                        <td><input type="text" id="empid"/></td>
                                    </tr>
                                    <tr>
                                    <td><label>Enter Employee Name:</label></td>
                                    <td><input type="text" id="empname"/></td>
                                    </tr>
                                    <tr>
                                    <td><label>Enter Employee Location:</label></td>
                                    <td><input type="text" id="emploc"/></td>
                                    </tr>
                                    <tr>
                                    <td><label>Enter Employee Salary:</label></td>
                                    <td><input type="text" id="empsal"/></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td><input type="submit" value="Submit"></input></td>
                                    </tr>
                                    </tbody>
                                </table>

                            </form>
                       </Col>
                 </Row>
             </Container>
        )
    }
}

export default EmployeeInsertComponent;