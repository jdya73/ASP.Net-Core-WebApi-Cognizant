﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiSwagger.Controllers
{
    [Route("api/emp")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        List<Employee> employees = new List<Employee>()
        {
            new Employee(){Id=1,Name="Ram",Location="Kolkata",Salary=60000},
            new Employee(){Id=2,Name="Sam",Location="Mumbai",Salary=29000 },
            new Employee(){Id=3,Name="John",Location="Delhi",Salary=32000},
            new Employee(){Id=4,Name="Tonny",Location="Pune",Salary=85000}
        };

        [HttpGet]
        public IEnumerable<Employee> get()
        {
            return employees;
        }

    }
}
